<table width="800" border="2" align="center">
    <thead>
    <tr>
        <th><a href="cadastro_usuario.php">Cadastrar Usuário</a></th>
        <th><a href="cadastro_serie.php">Cadastrar Série</a></th>
        <th><a href="cadastro_temporada.php">Cadastrar Temporada</a></th>
        <th><a href="cadastro_epsodio.php">Cadastrar Epsódio</a></th>
    </tr>
    </thead>
</table>
<br/><br/>